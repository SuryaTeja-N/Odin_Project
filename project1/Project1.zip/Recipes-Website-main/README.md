# Recipes-Website
A toy HTML website for showcasing recipes in pop culture

Live site: https://jason-b-jiang.github.io/Recipes-Website/

NOTE: I stopped the Odin Project a long time ago and switched my focus to data science/analytics instead, but I hope this repo can be a good reference for your first Odin Project assignment. Cheers :)
